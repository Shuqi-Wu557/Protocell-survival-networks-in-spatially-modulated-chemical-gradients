function [dd_input_C] = Diffusion_3D(input_C,D,dt,L)

input_C_x1=cat(1,input_C(2:end,:,:),input_C(end,:,:));
input_C_x2=cat(1,input_C(1,:,:),input_C(1:end-1,:,:));
input_C_y1=cat(2,input_C(:,2:end,:),input_C(:,end,:));
input_C_y2=cat(2,input_C(:,1,:),input_C(:,1:end-1,:));
input_C_z1=cat(3,input_C(:,:,2:end),input_C(:,:,end));
input_C_z2=cat(3,input_C(:,:,1),input_C(:,:,1:end-1));
%calculate concentration change in cube-cube diffusion, unit: M
dd_input_C=D*(input_C_x1+input_C_x2+input_C_y1+input_C_y2+input_C_z1+input_C_z2-6.*input_C).*dt./((L^2)*(10^-8));

end

