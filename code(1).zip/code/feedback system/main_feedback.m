%% initial concentartion
CTCEP0=100*(10^-3);CSS0=5*(10^-6);CBSA0=3*(10^-9);%initial concentration in a cube, unit: M
CAGx0=4.16*10^3;%unit: microg/ml
nx=133;ny=5;nz=5;
n=5000;%iteration
CSS=zeros(nx,ny,nz,n);CTCEP=zeros(nx,ny,nz,n);CGlu=zeros(nx,ny,nz,n);
CH2O2=zeros(nx,ny,nz,n);%chamber is divided to 133x27x17 cubes
CSS(:,:,:,1)=CSS0;CTCEP(1:3,:,:,1)=CTCEP0;
CBSA1=zeros(nx,ny,nz,n);%BSA in hydrogel
CBSA_in=zeros(nx,ny,nz,n);CBSA_in(:,:,:,1)=CBSA0;
CAGx1=zeros(nx,ny,nz,n);%AGx in hydrogel
CAGx_in=zeros(nx,ny,nz,n);
flag=rand([nx,ny,nz]);
flag(flag<=0.5)=0;
flag(flag>0.5)=1;
len0=find(flag==0);len1=find(flag==1);
CAGx_in(flag==1)=CAGx0;
%AGx-psomes: flag=1; GOx-psomes: flag=0;
d=43.25;r=12.5;

%% iteration
t12=zeros(nx,ny,nz);t=0;T=zeros(1,n);
k=1;dt=9;
for p=1:5000
    mark=0;
    [CTCEP,CGlu,CH2O2,CSS,CBSA1,CBSA_in,CAGx1,CAGx_in] = Iteration3(k,dt,CTCEP,CGlu,CH2O2,CSS,CBSA1,CBSA_in,CAGx1,CAGx_in,flag,nx,ny,nz,d,r);
    t=t+dt;k=k+1;
    
    par_CSS=CSS(:,:,:,k);par_CSS=par_CSS(:);
    par_CSS1=CSS(:,:,:,k-1);par_CSS1=par_CSS1(:);
    par_CTCEP=CTCEP(:,:,:,k);par_CTCEP=par_CTCEP(:);
    par_CTCEP1=CTCEP(:,:,:,k-1);par_CTCEP1=par_CTCEP1(:);
    par_CH2O2=CH2O2(:,:,:,k);par_CH2O2=par_CH2O2(:);
    par_CH2O21=CH2O2(:,:,:,k-1);par_CH2O21=par_CH2O21(:);
    par_CGlu=CGlu(:,:,:,k);par_CGlu=par_CGlu(:);
    par_CGlu1=CGlu(:,:,:,k-1);par_CGlu1=par_CGlu1(:);
    parfor z=1:length(par_CSS)
        if par_CSS(z)<0
           if par_CTCEP1(z)>CSS0||par_CSS1(z)<10^(-14)
               par_CSS(z)=0;
           end
        end
        if par_CTCEP(z)<0
            if par_CTCEP1(z)<(CSS0+par_CH2O21(z))||par_CTCEP1(z)<10^(-14)||dt<5
                par_CTCEP(z)=0;
            end
        end        
        if par_CH2O2(z)<0
            if par_CH2O21(z)<par_CTCEP1(z)||par_CH2O21(z)<10^(-14)||dt<5
                par_CH2O2(z)=0;
            end
        end
        if par_CGlu(z)<0
            if dt<5||par_CGlu1(z)<10^(-14)
                par_CGlu(z)=0;
            end
        end
    end
    CSS(:,:,:,k)=reshape(par_CSS,nx,ny,nz);
    CTCEP(:,:,:,k)=reshape(par_CTCEP,nx,ny,nz);
    CH2O2(:,:,:,k)=reshape(par_CH2O2,nx,ny,nz);
    CGlu(:,:,:,k)=reshape(par_CGlu,nx,ny,nz);
    for z=1:length(par_CSS)
        if par_CTCEP(z)<0||par_CH2O2(z)<0||par_CSS(z)<0||par_CGlu(z)<0
            k=k-1;
            t=t-dt;
            mark=1;
            m=z;
            dt=dt-3;
            break;
        end
    end                
    if mark==0&&dt<9
        dt=9;
    end
    
    T(k)=t./60;
end
for z=1:nz
    for j=1:ny
        for i=1:nx
            for kk=1:k
                if CBSA_in(i,j,z,kk)<=CBSA0*0.5&&CBSA_in(i,j,z,kk-1)>=CBSA0*0.5    
                    t12(i,j,z)=T(kk);%unit: min
                end
            end
        end
    end
end
figure;plot(t12(:,3,3));