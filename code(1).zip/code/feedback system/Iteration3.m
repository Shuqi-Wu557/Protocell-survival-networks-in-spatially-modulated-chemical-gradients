function [CTCEP,CGlu,CH2O2,CSS,CBSA1,CBSA_in,CAGx1,CAGx_in] = Iteration3(k,dt,CTCEP,CGlu,CH2O2,CSS,CBSA1,CBSA_in,CAGx1,CAGx_in,flag,nx,ny,nz,d,r)
L=150;%unit: micron
V_psomes=4/3*pi*r^3;%for AGx unit: micron3
DTCEP=6*(10^-6);DGlu=6*(10^-6);DBSA1=6.5*(10^-7);DH2O2=6.75*(10^-6);
DAGx1=5*(10^-7);%diffusion coefficient, unit: cm2/s
A1=0.91163;A2=-0.07407;x0=0.07418;p=0.58709;%DBSA2=A2+(A1-A2)/(1+(CSS/x0)^p);
AA1=0.52944;AA2=-0.03822;Ax0=0.39436;Ap=1.03538;%DAGx2=AA2+(AA1-AA2)/(1+(CSS/Ax0)^Ap);

%reaction
k0=18.4.*CAGx1(:,:,:,k)./(30.4+CAGx1(:,:,:,k));%rate constant for AGx vs C(AGx),unit: microM/s

par_CGlu=CGlu(:,:,:,k);par_CGlu1=par_CGlu(:);
par_CH2O2=CH2O2(:,:,:,k);par_CH2O21=par_CH2O2(:);
par_CTCEP=CTCEP(:,:,:,k);par_CTCEP1=par_CTCEP(:);
par_CSS=CSS(:,:,:,k);par_CSS1=par_CSS(:);
par_k0=k0(:);par_flag=flag(:);

parfor i=1:length(par_CGlu1)
    y=[par_CGlu1(i) par_CH2O21(i) par_CTCEP1(i) par_CSS1(i)];
    y(y<10^(-16))=0;
    [par_drCGlu(i),par_drCH2O2(i),par_drCTCEP(i),par_drCSS(i)]=reaction3(dt,y,par_k0(i),par_flag(i));
end
drCGlu=reshape(par_drCGlu,nx,ny,nz);
drCH2O2=reshape(par_drCH2O2,nx,ny,nz);
drCTCEP=reshape(par_drCTCEP,nx,ny,nz);
drCSS=reshape(par_drCSS,nx,ny,nz);
    
%diffusion
%between the cubes
%iterations: k; between the cubes, consider x,y,z-axis diffusion
%calculate concentration change in cube-cube diffusion, unit: M
ddCTCEP=Diffusion_3D(CTCEP(:,:,:,k),DTCEP,dt,L);
ddCBSA1=Diffusion_3D(CBSA1(:,:,:,k),DBSA1,dt,L);
ddCGlu=Diffusion_3D(CGlu(:,:,:,k),DGlu,dt,L);
ddCH2O2=Diffusion_3D(CH2O2(:,:,:,k),DH2O2,dt,L);
ddCAGx1=Diffusion_3D(CAGx1(:,:,:,k),DAGx1,dt,L);

%in the cube
DBSA2=(A2+(A1-A2)./(1+((CSS(:,:,:,k).*10^6)./x0).^p))*10^(-8);%unit: cm2/s;
DAGx2=(AA2+(AA1-AA2)./(1+((CSS(:,:,:,k).*10^6)./Ax0).^Ap))*10^(-8);%unit: cm2/s;
DAGx2(DAGx2<0)=0;

ddCBSA_in=(-6*dt.*DBSA2.*(CBSA_in(:,:,:,k)-CBSA1(:,:,:,k)))./((d^2)*(10^-8));%unit: M
ddMBSA_in=-ddCBSA_in.*V_psomes;%unit: 10^-15mol
ddCBSA_out=ddMBSA_in./(150^3-V_psomes);%unit: M
ddCAGx_in=flag.*((-6*dt.*DAGx2.*(CAGx_in(:,:,:,k)-CAGx1(:,:,:,k)))./((d^2)*(10^-8)));%unit: microg/ml
ddMAGx_in=-ddCAGx_in.*V_psomes;
ddCAGx_out=ddMAGx_in./(150^3-V_psomes);%unit: microg/ml
    
%calculation next iteration
CTCEP(:,:,:,k+1)=CTCEP(:,:,:,k)+drCTCEP+ddCTCEP;
CSS(:,:,:,k+1)=CSS(:,:,:,k)+drCSS;
CGlu(:,:,:,k+1)=CGlu(:,:,:,k)+drCGlu+ddCGlu;
CH2O2(:,:,:,k+1)=CH2O2(:,:,:,k)+drCH2O2+ddCH2O2;
CBSA_in(:,:,:,k+1)=CBSA_in(:,:,:,k)+ddCBSA_in;
CBSA1(:,:,:,k+1)=CBSA1(:,:,:,k)+ddCBSA1+ddCBSA_out;
CAGx_in(:,:,:,k+1)=CAGx_in(:,:,:,k)+ddCAGx_in;
CAGx1(:,:,:,k+1)=CAGx1(:,:,:,k)+ddCAGx1+ddCAGx_out;

end