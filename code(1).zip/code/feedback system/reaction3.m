function [drCGlu,drCH2O2,drCTCEP,drCSS]=reaction3(dt,y,k0,flag)

y=y.*10^6;%unit: microM
if flag==0
    k1=1.51*(10^-5);%unit: microM-1s-1
else
    k1=0;
end
k2=5.6*(10^2);k3=0.83*(10^-6);%unit: microM-1s-1
CO2=267;%unit: microM
[~,y_out]=ode23s(@func,[0 dt],y);
%calculate concentration change in reaction, unit: M

%The integral function oscillates because the value is too small
for i=1:4
    for j=1:length(y_out(:,1))    
        if y_out(j,i)<0
            if y(i)<10^(-9)
                y_out(end,i)=y(i);
            else
                y_out(end,i)=abs(y_out(end,i));
            end
        end        
    end
end

drCGlu=(y_out(end,1)-y(1))./(10^6);
drCH2O2=(y_out(end,2)-y(2))./(10^6);
drCTCEP=(y_out(end,3)-y(3))./(10^6);
drCSS=(y_out(end,4)-y(4))./(10^6);

%discribe differential equations
function dy=func(~,y) 
dy=zeros(4,1); 
dy(1)=k0-k1*y(1)*CO2;
dy(2)=k1*y(1)*CO2-k2*y(2)*y(3);
dy(3)=-k2*y(2)*y(3)-k3*y(3)*y(4);
dy(4)=-k3*y(3)*y(4);
end

end