function [drCTCEP,drCSS]=reaction1(dt,y,k3)

y=y.*10^3;%unit: mM
[~,y_out]=ode23s(@func2,[0 dt],y);
%calculate concentration change in reaction, unit: M
drCTCEP=(y_out(end,1)-y(1))./(10^3);
drCSS=(y_out(end,2)-y(2))./(10^3);

%discribe differential equations
function dy=func2(~,y) 
dy=zeros(2,1); 
dy(1)=-k3*y(1)*y(2);
dy(2)=-k3*y(1)*y(2);
end

end