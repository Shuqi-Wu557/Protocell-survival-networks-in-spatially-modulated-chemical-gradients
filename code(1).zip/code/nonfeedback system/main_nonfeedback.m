%% initial concentration
CSS0=5*(10^-6);CTCEP0=50*(10^-6);CBSA0=3*(10^-9);%initial concentration in a cube, unit: M
n=5000;%iteration
CSS=zeros(n,m);CTCEP=zeros(n,m);%chamber is divided to 133x27x17 cubes
CSS(1,:)=CSS0;CTCEP(1,1:3)=CTCEP0;
dt=9;%unit: s
L=150;d=43.75;%unit: micron
V_psomes=4/3*pi*12.5^3;%unit: micron3
DTCEP=6*(10^-6);DBSA1=6.5*(10^-7);%diffusion coefficient, unit: cm2/s
t12=zeros(1,m);DBSA2=zeros(n,m);
CBSA1=zeros(n,m);%BSA in hydrogel                                                                                    
CBSA_in=zeros(n,m);CBSA_in(1,:)=CBSA0;
A1=0.91163;A2=-0.07407;x0=0.07418;p=0.58709;%DBSA2=A2+(A1-A2)/(1+(CSS/x0)^p);
%Allocate space for intermediate parameters
CTCEP_1=zeros(n,m);CTCEP_2=zeros(n,m);
CBSA1_1=zeros(n,m);CBSA1_2=zeros(n,m);
drCTCEP=zeros(n,m);drCSS=zeros(n,m);
ddCTCEP=zeros(n,m);ddCBSA1=zeros(n,m);
ddCBSA_in=zeros(n,m);ddMBSA_in=zeros(n,m);ddCBSA_out=zeros(n,m);
k3=0.83*(10^-3);%rate for reducing reaction; unit: mM-1s-1

%% calculation
for k=1:n
    %reaction
    for i=1:m
        y=[CTCEP(k,i) CSS(k,i)];
        for q=1:2
            if y(q)<10^(-16)
                y(q)=0;
            end
        end
        [drCTCEP(k,i),drCSS(k,i)]=reaction1(dt,y,k3);
    end
    
    %diffusion
    %between the cubes
    %iterations: k; between the cubes, consider x-axis diffusion
    CTCEP_1(k,:)=[CTCEP(k,2:end) CTCEP(k,end)];CTCEP_2(k,:)=[CTCEP(k,1) CTCEP(k,1:end-1)];
    CBSA1_1(k,:)=[CBSA1(k,2:end) CBSA1(k,end)];CBSA1_2(k,:)=[CBSA1(k,1) CBSA1(k,1:end-1)];
    %calculate concentration change in cube-cube diffusion, unit: M
    ddCTCEP(k,:)=DTCEP*(CTCEP_1(k,:)+CTCEP_2(k,:)-2*CTCEP(k,:))*dt/((L^2)*(10^-8));
    ddCBSA1(k,:)=DBSA1*(CBSA1_1(k,:)+CBSA1_2(k,:)-2*CBSA1(k,:))*dt/((L^2)*(10^-8));
    
    %in the cube
    DBSA2(k,:)=(A2+(A1-A2)./(1+((CSS(k,:).*10^6)./x0).^p))*10^(-8);%unit: cm2/s;
    %consider that without TCEP, BSA won't leak out
    for a=1:m
        if DBSA2(k,a)<0
            DBSA2(k,a)=0;
        end
    end
    ddCBSA_in(k,:)=(-6*dt.*DBSA2(k,:).*(CBSA_in(k,:)-CBSA1(k,:)))./((d^2)*(10^-8));%unit: M
    ddMBSA_in(k,:)=-ddCBSA_in(k,:).*V_psomes;%unit: 10^-15mol
    ddCBSA_out(k,:)=ddMBSA_in(k,:)./(150^3-V_psomes);%unit: M
    
    %calculation next iteration
    CTCEP(k+1,:)=CTCEP(k,:)+drCTCEP(k,:)+ddCTCEP(k,:);
    CSS(k+1,:)=CSS(k,:)+drCSS(k,:);
    CBSA_in(k+1,:)=CBSA_in(k,:)+ddCBSA_in(k,:);
    CBSA1(k+1,:)=CBSA1(k,:)+ddCBSA1(k,:)+ddCBSA_out(k,:);
    for z=1:m
        if CTCEP(k+1,z)<0
            return;
        end
    end
    for z=1:m
        if CSS(k+1,z)<0&&CTCEP(k,z)>CSS0
            CSS(k+1,z)=0;
        end
    end
    
    %t12: half life time of fluorescence intensity
    for j=1:m
        if CBSA_in(k+1,j)<=CBSA0*0.5&&CBSA_in(k,j)>=CBSA0*0.5
            t12(j)=k*dt./60;%unit: min
        end
    end
end